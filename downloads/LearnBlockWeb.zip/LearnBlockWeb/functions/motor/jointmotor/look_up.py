

def look_up(lbot):
    lbot.setJointAngle(30, "CAMERA")
