

def look_floor(lbot):
    lbot.setJointAngle(-30, "CAMERA")
