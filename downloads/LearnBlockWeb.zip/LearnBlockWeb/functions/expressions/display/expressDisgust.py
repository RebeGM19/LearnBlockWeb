from learnbot_dsl.Clients.Devices import Emotions


def expressDisgust(lbot):
    lbot.express(Emotions.Disgust)
