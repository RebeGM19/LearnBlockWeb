

def setAngleCamera(lbot,angle):
    lbot.setJointAngle(angle, "CAMERA")
