from __future__ import print_function, absolute_import

def stop_bot(lbot):
	lbot.setBaseSpeed(0, 0)

