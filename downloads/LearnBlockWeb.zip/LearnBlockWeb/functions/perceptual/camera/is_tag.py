from __future__ import print_function, absolute_import

def is_tag(lbot, idTag=8):
    return lbot.lookingLabel(idTag)