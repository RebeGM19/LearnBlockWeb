

def look_front(lbot):
    lbot.setJointAngle(0, "CAMERA")
