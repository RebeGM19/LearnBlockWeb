from __future__ import print_function, absolute_import
import os, sys

path = os.path.dirname(os.path.realpath(__file__))
__version__ = '0.3.22'

__LBversion__ = '3.1.6'

PATHINTERFACES = os.path.join(path, "interfaces")
PATHCLIENT = os.path.join(path, "Clients")

file = os.path.join(os.getenv('HOME'), ".learnblock", "AprilDict.json")

def getAprilTextDict():
    if os.path.exists(file):
        with open(file, "r") as f:
            dictAprilTags = json.load(f)
        return dictAprilTags
    return {}
