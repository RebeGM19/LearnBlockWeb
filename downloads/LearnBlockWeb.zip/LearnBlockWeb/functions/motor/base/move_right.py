from __future__ import print_function, absolute_import
import time
def move_right(lbot, advSpeed=20, rotSpeed=15):
	lbot.setBaseSpeed(advSpeed, rotSpeed)

