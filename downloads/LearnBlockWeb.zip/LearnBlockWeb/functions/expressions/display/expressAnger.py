from learnbot_dsl.Clients.Devices import Emotions

def expressAnger(lbot):
    lbot.express(Emotions.Anger)
