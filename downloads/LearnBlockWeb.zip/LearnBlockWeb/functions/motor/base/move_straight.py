import time


def move_straight(lbot, advSpeed=40):
	lbot.setBaseSpeed(advSpeed, 0)

