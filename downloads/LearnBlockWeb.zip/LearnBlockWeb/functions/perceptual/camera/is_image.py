
def is_image(lbot, id):
    return lbot.lookingLabel(id)
