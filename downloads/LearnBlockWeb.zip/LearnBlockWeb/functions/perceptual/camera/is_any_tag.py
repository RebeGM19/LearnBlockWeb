from __future__ import print_function, absolute_import

def is_any_tag(lbot):
    return len(lbot.listTags()) is not 0
